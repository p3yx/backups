<?php
// create.php - Buat akun baru
require_once 'header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $server_id = $_POST['server_id'];
    $hari = intval($_POST['hari']);
    $result = createAccount($_SESSION['user_id'], $server_id, $hari);

    if ($result['success']) {
        $message = "Akun berhasil dibuat. Username: {$result['username']} | Password: {$result['password']}";
    } else {
        $error = $result['message'];
    }
}

$servers = getServers();
?>

<div class="card p-6">
    <h2 class="text-xl font-bold mb-4">Buat Akun Baru</h2>
    <?php if (!empty($message)): ?>
        <div class="p-4 mb-4 bg-green-800 rounded"><?php echo htmlspecialchars($message); ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="p-4 mb-4 bg-red-800 rounded"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <label class="block mb-2">Pilih Server</label>
        <select name="server_id" class="w-full p-2 mb-4 rounded bg-gray-800">
            <?php foreach ($servers as $server): ?>
                <option value="<?php echo $server['id']; ?>">
                    <?php echo htmlspecialchars($server['nama_server']); ?> (<?php echo formatCurrency($server['harga']); ?>/hari)
                </option>
            <?php endforeach; ?>
        </select>

        <label class="block mb-2">Durasi (hari)</label>
        <input type="number" name="hari" min="1" value="7" class="w-full p-2 mb-4 rounded bg-gray-800">

        <button type="submit" class="px-4 py-2 bg-green-700 rounded hover:bg-green-600">Buat Akun</button>
    </form>
</div>

<?php require_once 'footer.php'; ?>
