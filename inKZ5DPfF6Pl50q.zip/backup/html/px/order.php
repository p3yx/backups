<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fungsi untuk menghasilkan kode order unik
function generateOrderCode() {
    return 'PX' . date('Ymd') . strtoupper(substr(uniqid(), -6));
}

// Fungsi untuk validasi nomor telepon Indonesia
function validatePhoneNumber($phone) {
    // Hapus karakter non-digit
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Cek panjang nomor (10-13 digit)
    if (strlen($phone) < 10 || strlen($phone) > 13) {
        return false;
    }
    
    // Cek apakah diawali dengan 0 atau 62
    if (substr($phone, 0, 1) === '0') {
        // Format 08xxx
        return true;
    } elseif (substr($phone, 0, 2) === '62') {
        // Format 628xxx
        return true;
    }
    
    return false;
}

// Ambil data dari request
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Data order tidak valid'
    ]);
    exit;
}

// Validasi data
$errors = [];

if (empty($input['productCode'])) {
    $errors[] = 'Kode produk tidak valid';
}

if (empty($input['productName'])) {
    $errors[] = 'Nama produk tidak valid';
}

if (empty($input['productPrice']) || !is_numeric($input['productPrice'])) {
    $errors[] = 'Harga produk tidak valid';
}

if (empty($input['phoneNumber']) || !validatePhoneNumber($input['phoneNumber'])) {
    $errors[] = 'Nomor telepon tidak valid. Gunakan format 08xxx atau 628xxx';
}

if (empty($input['customerName'])) {
    $errors[] = 'Nama pemesan harus diisi';
}

if (empty($input['paymentMethod'])) {
    $errors[] = 'Metode pembayaran harus dipilih';
}

// Jika ada error, kembalikan pesan error
if (!empty($errors)) {
    echo json_encode([
        'success' => false,
        'message' => implode(', ', $errors)
    ]);
    exit;
}

// Format nomor telepon (standarkan ke 62)
$phoneNumber = preg_replace('/[^0-9]/', '', $input['phoneNumber']);
if (substr($phoneNumber, 0, 1) === '0') {
    $phoneNumber = '62' . substr($phoneNumber, 1);
}

// Simpan data order (di sini Anda bisa menyimpannya ke database)
$orderData = [
    'order_code' => generateOrderCode(),
    'product_code' => $input['productCode'],
    'product_name' => $input['productName'],
    'product_price' => (int)$input['productPrice'],
    'phone_number' => $phoneNumber,
    'customer_name' => $input['customerName'],
    'payment_method' => $input['paymentMethod'],
    'order_date' => date('Y-m-d H:i:s'),
    'status' => 'pending'
];

// Di sini Anda bisa menambahkan kode untuk menyimpan ke database
// Contoh: 
// $db->insert('orders', $orderData);

// Untuk sementara, kita simpan ke file JSON (hanya untuk demo)
$ordersFile = 'orders.json';
$allOrders = [];

if (file_exists($ordersFile)) {
    $allOrders = json_decode(file_get_contents($ordersFile), true) ?: [];
}

$allOrders[] = $orderData;
file_put_contents($ordersFile, json_encode($allOrders, JSON_PRETTY_PRINT));

// Kirim notifikasi (opsional)
// Anda bisa mengintegrasikan dengan WhatsApp API atau Telegram API di sini

// Response sukses
echo json_encode([
    'success' => true,
    'message' => 'Order berhasil diproses',
    'orderCode' => $orderData['order_code'],
    'data' => $orderData
]);
