<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$apiUrl = "https://www.okeconnect.com/harga/json?id=905ccd028329b0a&produk=pulsa,kuota_telkomsel,kuota_byu,kuota_indosat,kuota_tri,kuota_xl,kuota_axis,kuota_smartfren,ecommerce,digital";

// Ambil data dari API
$response = null;

// Coba pakai cURL kalau ada
if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        echo json_encode([
            "error" => true,
            "message" => "Gagal mengambil data dari OkeConnect (cURL): $err"
        ]);
        exit;
    }
}
// Kalau cURL tidak ada, fallback ke file_get_contents
else {
    $response = @file_get_contents($apiUrl);
    if ($response === false) {
        echo json_encode([
            "error" => true,
            "message" => "Gagal mengambil data dari OkeConnect (file_get_contents)"
        ]);
        exit;
    }
}

// Decode JSON
$data = json_decode($response, true);
if (!$data) {
    echo json_encode([
        "error" => true,
        "message" => "Format JSON tidak valid",
        "raw" => substr($response, 0, 300)
    ]);
    exit;
}

// Normalisasi data
$products = [];

// Kalau API balikin root "data"
if (isset($data['data']) && is_array($data['data'])) {
    $list = $data['data'];
} elseif (is_array($data)) {
    $list = $data;
} else {
    $list = [];
}

// Fungsi untuk menentukan kategori berdasarkan nama produk
function determineCategory($productName) {
    $name = strtolower($productName);
    
    if (strpos($name, 'axis') !== false) return 'Axis';
    if (strpos($name, 'indosat') !== false || strpos($name, 'im3') !== false) return 'Indosat';
    if (strpos($name, 'telkomsel') !== false || strpos($name, 'tsel') !== false) return 'Telkomsel';
    if (strpos($name, 'tri') !== false) return 'Tri';
    if (strpos($name, 'xl') !== false) return 'XL';
    if (strpos($name, 'by.u') !== false || strpos($name, 'byu') !== false) return 'BY.U';
    if (strpos($name, 'smartfren') !== false) return 'Smartfren';
    if (strpos($name, 'pulsa') !== false) return 'Pulsa';
    if (strpos($name, 'google') !== false || strpos($name, 'steam') !== false || 
        strpos($name, 'voucher') !== false || strpos($name, 'game') !== false) return 'Voucher Game';
    
    return 'Lainnya';
}

foreach ($list as $item) {
    $productName = $item['keterangan'] ?? $item['produk'] ?? "Produk";
    
    $products[] = [
        "name" => $productName,
        "description" => $item['produk'] ?? "-",
        "code" => $item['kode'] ?? "",
        "price" => (int)($item['harga'] ?? 0),
        "status" => ($item['status'] ?? $item['aktif'] ?? "0") == "1" ? "available" : "gangguan",
        "category" => determineCategory($productName)
    ];
}

// Output JSON final
echo json_encode(["data" => $products], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
