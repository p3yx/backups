<?php
// config.php - Konfigurasi database dan setting
define('DB_PATH', '/root/sellbot/sellvpn.db');
define('SITE_NAME', 'PXSTORE');
define('CURRENCY', 'Rp');
define('API_BASE_URL', 'http://localhost:3000/api'); // Ganti dengan URL API yang sesuai

// Mulai session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Koneksi ke database SQLite
function getDB() {
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Fungsi untuk memanggil API
function callAPI($endpoint, $method = 'GET', $data = []) {
    $url = API_BASE_URL . $endpoint;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } elseif ($method === 'PUT') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } elseif ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        return json_decode($response, true);
    } else {
        error_log("API call failed: $endpoint, HTTP Code: $httpCode");
        return false;
    }
}

// Format mata uang
function formatCurrency($amount) {
    return CURRENCY . number_format($amount, 0, ',', '.');
}

// =============================
// AUTH & ROLE
// =============================
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isReseller() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'reseller';
}

// =============================
// USER & BALANCE
// =============================
function getUserBalance($user_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT saldo FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['saldo'] : 0;
}

function hasUnlimitedTrial($user_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM unlimited_trial_users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch() !== false;
}

// =============================
// UI CONFIG
// =============================
function isTrialButtonActive() {
    $db = getDB();
    $stmt = $db->query("SELECT show_trial_button FROM ui_config WHERE id = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_trial_button'] == 1;
}

function isSewaScriptButtonActive() {
    $db = getDB();
    $stmt = $db->query("SELECT show_sewa_script_button FROM ui_config WHERE id = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_sewa_script_button'] == 1;
}

function isUpgradeResellerButtonActive() {
    $db = getDB();
    $stmt = $db->query("SELECT show_upgrade_reseller_button FROM ui_config WHERE id = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_upgrade_reseller_button'] == 1;
}

// =============================
// SERVER (Menggunakan API)
// =============================
function getServers() {
    $result = callAPI('/servers');
    if ($result && isset($result['success']) && $result['success']) {
        return $result['data'];
    }
    
    // Fallback ke database jika API tidak tersedia
    $db = getDB();
    $stmt = $db->query("SELECT * FROM Server ORDER BY nama_server ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getServerAuth($serverId) {
    $result = callAPI("/servers/$serverId/auth");
    if ($result && isset($result['success']) && $result['success']) {
        return $result['data'];
    }
    
    // Fallback ke database jika API tidak tersedia
    $db = getDB();
    $stmt = $db->prepare("SELECT auth FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['auth'] : '';
}

function getServerDetails($serverId) {
    $result = callAPI("/servers/$serverId");
    if ($result && isset($result['success']) && $result['success']) {
        return $result['data'];
    }
    
    // Fallback ke database jika API tidak tersedia
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// =============================
// VPN ACCOUNT MANAGEMENT (Menggunakan API)
// =============================
function createVPNAccount($serverId, $username, $password, $expiryDate) {
    $data = [
        'server_id' => $serverId,
        'username' => $username,
        'password' => $password,
        'expiry_date' => $expiryDate
    ];
    
    return callAPI('/accounts', 'POST', $data);
}

function renewVPNAccount($accountId, $extensionDays) {
    $data = ['extension_days' => $extensionDays];
    return callAPI("/accounts/$accountId/renew", 'POST', $data);
}

function deleteVPNAccount($accountId) {
    return callAPI("/accounts/$accountId", 'DELETE');
}

function getVPNAccountStatus($accountId) {
    return callAPI("/accounts/$accountId/status");
}

// =============================
// STATS (Menggunakan API jika tersedia)
// =============================
function getUserStats($user_id) {
    $result = callAPI("/stats/user/$user_id");
    if ($result && isset($result['success']) && $result['success']) {
        return $result['data'];
    }
    
    // Fallback ke database jika API tidak tersedia
    $db = getDB();
    $todayStart = date('Y-m-d 00:00:00');
    $weekStart = date('Y-m-d 00:00:00', strtotime('this week'));
    $monthStart = date('Y-m-01 00:00:00');

    $stats = ['today'=>0,'week'=>0,'month'=>0];

    foreach (['today'=>$todayStart, 'week'=>$weekStart, 'month'=>$monthStart] as $key=>$time) {
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan 
            WHERE user_id = ? AND waktu_transaksi >= ? AND action_type IN ('create','renew')");
        $stmt->execute([$user_id, $time]);
        $stats[$key] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    }
    return $stats;
}

function getGlobalStats() {
    $result = callAPI('/stats/global');
    if ($result && isset($result['success']) && $result['success']) {
        return $result['data'];
    }
    
    // Fallback ke database jika API tidak tersedia
    $db = getDB();
    $todayStart = date('Y-m-d 00:00:00');
    $weekStart = date('Y-m-d 00:00:00', strtotime('this week'));
    $monthStart = date('Y-m-01 00:00:00');

    $stats = ['today'=>0,'week'=>0,'month'=>0,'total_users'=>0,'total_servers'=>0];

    foreach (['today'=>$todayStart, 'week'=>$weekStart, 'month'=>$monthStart] as $key=>$time) {
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan 
            WHERE waktu_transaksi >= ? AND action_type IN ('create','renew')");
        $stmt->execute([$time]);
        $stats[$key] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    }

    $stats['total_users'] = $db->query("SELECT COUNT(*) as count FROM users")->fetch(PDO::FETCH_ASSOC)['count'];
    $stats['total_servers'] = $db->query("SELECT COUNT(*) as count FROM Server")->fetch(PDO::FETCH_ASSOC)['count'];

    return $stats;
}

// =============================
// DISCOUNT & PRICE
// =============================
function getResellerDiscount() {
    $db = getDB();
    $stmt = $db->query("SELECT discount_percent FROM reseller_config WHERE id = 1");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['discount_percent'] : 0;
}

function getDiscountedPrice($originalPrice, $userRole) {
    if ($userRole === 'reseller') {
        $discount = getResellerDiscount();
        return floor($originalPrice * (100 - $discount) / 100);
    }
    return $originalPrice;
}
?>
