<?php
$database["host"] = "localhost";
$database["name"] = "gacor";
$database["user"] = "gacoruser";
$database["password"] = "passwordku";

require_once __DIR__ . "/../admin/classes/database.class.php";
database::connect(
    "mysql:host=" . $database["host"] . ";dbname=" . $database["name"],
    $database["user"],
    $database["password"]
);
