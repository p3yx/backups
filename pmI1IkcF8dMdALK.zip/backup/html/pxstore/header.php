<?php
// header.php - Header untuk semua halaman
require_once 'config.php';

// Redirect ke login jika belum login
if (!isLoggedIn() && basename($_SERVER['PHP_SELF']) != 'login.php') {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-primary: #1a202c;
            --bg-secondary: #2d3748;
            --text-primary: #e2e8f0;
            --text-secondary: #a0aec0;
            --accent: #4299e1;
            --success: #48bb78;
            --warning: #ed8936;
            --danger: #f56565;
        }
        
        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
        }
        
        .card {
            background-color: var(--bg-secondary);
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-primary {
            background-color: var(--accent);
            color: white;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background-color: #3182ce;
            transform: translateY(-2px);
        }
        
        .stat-card {
            background: linear-gradient(135deg, var(--bg-secondary) 0%, #3c366b 100%);
        }
        
        .menu-item {
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover, .menu-item.active {
            background-color: rgba(66, 153, 225, 0.1);
            border-left-color: var(--accent);
        }
        
        /* Animasi */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <!-- Header -->
    <header class="bg-gray-800 text-white py-4 px-6 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <i class="fas fa-shield-alt text-blue-400 text-2xl"></i>
                <h1 class="text-xl font-bold"><?php echo SITE_NAME; ?></h1>
            </div>
            
            <div class="flex items-center space-x-4">
                <?php if (isLoggedIn()): ?>
                <div class="hidden md:flex items-center space-x-2">
                    <i class="fas fa-wallet text-green-400"></i>
                    <span class="font-semibold"><?php echo formatCurrency(getUserBalance($_SESSION['user_id'])); ?></span>
                </div>
                
                <div class="hidden md:flex items-center space-x-2">
                    <i class="fas fa-user text-blue-400"></i>
                    <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <?php if (isAdmin()): ?>
                        <span class="bg-purple-600 px-2 py-1 rounded text-xs">ADMIN</span>
                    <?php elseif (isReseller()): ?>
                        <span class="bg-blue-600 px-2 py-1 rounded text-xs">RESELLER</span>
                    <?php else: ?>
                        <span class="bg-gray-600 px-2 py-1 rounded text-xs">MEMBER</span>
                    <?php endif; ?>
                </div>
                
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded flex items-center space-x-1">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="flex flex-1">
        <!-- Sidebar -->
        <?php if (isLoggedIn()): ?>
        <aside class="w-64 bg-gray-800 border-r border-gray-700 hidden md:block">
            <nav class="p-4 space-y-1">
                <a href="index.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home mr-2"></i> Dashboard
                </a>
                
                <?php if ((isTrialButtonActive() || hasUnlimitedTrial($_SESSION['user_id']) || isAdmin()) && basename($_SERVER['PHP_SELF']) != 'trial.php'): ?>
                <a href="trial.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'trial.php' ? 'active' : ''; ?>">
                    <i class="fas fa-vial mr-2"></i> Trial Akun
                </a>
                <?php endif; ?>
                
                <a href="create.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'create.php' ? 'active' : ''; ?>">
                    <i class="fas fa-plus-circle mr-2"></i> Buat Akun
                </a>
                
                <a href="renew.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'renew.php' ? 'active' : ''; ?>">
                    <i class="fas fa-sync-alt mr-2"></i> Renew Akun
                </a>
                
                <a href="topup.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'topup.php' ? 'active' : ''; ?>">
                    <i class="fas fa-money-bill-wave mr-2"></i> Top Up Saldo
                </a>
                
                <?php if (isSewaScriptButtonActive()): ?>
                <a href="sewascript.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'sewascript.php' ? 'active' : ''; ?>">
                    <i class="fas fa-code mr-2"></i> Sewa Script
                </a>
                <?php endif; ?>
                
                <?php if (($_SESSION['role'] != 'reseller' && isUpgradeResellerButtonActive()) || isAdmin()): ?>
                <a href="upgrade.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'upgrade.php' ? 'active' : ''; ?>">
                    <i class="fas fa-star mr-2"></i> Upgrade Reseller
                </a>
                <?php endif; ?>
                
                <?php if (isAdmin()): ?>
                <div class="pt-4 mt-4 border-t border-gray-700">
                    <p class="px-4 text-xs text-gray-400 uppercase tracking-wider">Admin Menu</p>
                    
                    <a href="admin_servers.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'admin_servers.php' ? 'active' : ''; ?>">
                        <i class="fas fa-server mr-2"></i> Kelola Server
                    </a>
                    
                    <a href="admin_users.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'admin_users.php' ? 'active' : ''; ?>">
                        <i class="fas fa-users mr-2"></i> Kelola User
                    </a>
                    
                    <a href="admin_settings.php" class="menu-item block py-2 px-4 rounded <?php echo basename($_SERVER['PHP_SELF']) == 'admin_settings.php' ? 'active' : ''; ?>">
                        <i class="fas fa-cog mr-2"></i> Pengaturan
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </aside>
        <?php endif; ?>

        <!-- Main Content -->
        <main class="flex-1 p-4 md:p-6 overflow-auto">