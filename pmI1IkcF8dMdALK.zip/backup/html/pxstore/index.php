<?php
// index.php - Halaman dashboard utama
require_once 'header.php';

// Ambil statistik
$userStats = getUserStats($_SESSION['user_id']);
$globalStats = getGlobalStats();
$servers = getServers();
?>

<div class="animate-fade-in">
    <!-- Welcome Banner -->
    <div class="card p-6 mb-6 bg-gradient-to-r from-blue-900 to-purple-900">
        <div class="flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold">Selamat Datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
                <p class="text-blue-200">Selamat menikmati layanan VPN terbaik dari <?php echo SITE_NAME; ?></p>
            </div>
            <div class="mt-4 md:mt-0 flex items-center space-x-2 bg-blue-800 bg-opacity-50 px-4 py-2 rounded-lg">
                <i class="fas fa-wallet text-green-400"></i>
                <span class="font-semibold">Saldo: <?php echo formatCurrency(getUserBalance($_SESSION['user_id'])); ?></span>
            </div>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <!-- User Today -->
        <div class="stat-card p-4 rounded-lg">
            <div class="flex justify-between items-center">
                <h3 class="text-sm font-medium text-gray-300">Hari Ini</h3>
                <i class="fas fa-calendar-day text-blue-400"></i>
            </div>
            <p class="text-2xl font-bold mt-2"><?php echo $userStats['today']; ?> akun</p>
        </div>
        
        <!-- User Week -->
        <div class="stat-card p-4 rounded-lg">
            <div class="flex justify-between items-center">
                <h3 class="text-sm font-medium text-gray-300">Minggu Ini</h3>
                <i class="fas fa-calendar-week text-green-400"></i>
            </div>
            <p class="text-2xl font-bold mt-2"><?php echo $userStats['week']; ?> akun</p>
        </div>
        
        <!-- User Month -->
        <div class="stat-card p-4 rounded-lg">
            <div class="flex justify-between items-center">
                <h3 class="text-sm font-medium text-gray-300">Bulan Ini</h3>
                <i class="fas fa-calendar-alt text-purple-400"></i>
            </div>
            <p class="text-2xl font-bold mt-2"><?php echo $userStats['month']; ?> akun</p>
        </div>
        
        <!-- Global Today -->
        <div class="stat-card p-4 rounded-lg">
            <div class="flex justify-between items-center">
                <h3 class="text-sm font-medium text-gray-300">Global Hari Ini</h3>
                <i class="fas fa-globe text-yellow-400"></i>
            </div>
            <p class="text-2xl font-bold mt-2"><?php echo $globalStats['today']; ?> akun</p>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <?php if ((isTrialButtonActive() || hasUnlimitedTrial($_SESSION['user_id']) || isAdmin()) && basename($_SERVER['PHP_SELF']) != 'trial.php'): ?>
        <a href="trial.php" class="card p-4 text-center hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-blue-800 to-blue-900">
            <i class="fas fa-vial text-3xl mb-2 text-blue-300"></i>
            <h3 class="font-semibold">Trial Akun</h3>
            <p class="text-sm text-gray-300">Coba layanan gratis</p>
        </a>
        <?php endif; ?>
        
        <a href="create.php" class="card p-4 text-center hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-green-800 to-green-900">
            <i class="fas fa-plus-circle text-3xl mb-2 text-green-300"></i>
            <h3 class="font-semibold">Buat Akun</h3>
            <p class="text-sm text-gray-300">Buat akun VPN baru</p>
        </a>
        
        <a href="renew.php" class="card p-4 text-center hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-yellow-800 to-yellow-900">
            <i class="fas fa-sync-alt text-3xl mb-2 text-yellow-300"></i>
            <h3 class="font-semibold">Renew Akun</h3>
            <p class="text-sm text-gray-300">Perpanjang masa aktif</p>
        </a>
        
        <a href="topup.php" class="card p-4 text-center hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-purple-800 to-purple-900">
            <i class="fas fa-money-bill-wave text-3xl mb-2 text-purple-300"></i>
            <h3 class="font-semibold">Top Up Saldo</h3>
            <p class="text-sm text-gray-300">Isi saldo akun Anda</p>
        </a>
    </div>

    <!-- Server List -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-server mr-2 text-blue-400"></i> Daftar Server Tersedia
        </h2>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-700">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Nama Server</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Domain</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Harga/Hari</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Quota</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Limit IP</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php foreach ($servers as $server): 
                        $hargaPerHari = getDiscountedPrice($server['harga'], $_SESSION['role']);
                        $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                    ?>
                    <tr>
                        <td class="px-4 py-3"><?php echo htmlspecialchars($server['nama_server']); ?></td>
                        <td class="px-4 py-3"><?php echo htmlspecialchars($server['domain']); ?></td>
                        <td class="px-4 py-3"><?php echo formatCurrency($hargaPerHari); ?></td>
                        <td class="px-4 py-3"><?php echo $server['quota']; ?> GB</td>
                        <td class="px-4 py-3"><?php echo $server['iplimit']; ?> IP</td>
                        <td class="px-4 py-3">
                            <?php if ($isFull): ?>
                                <span class="px-2 py-1 bg-red-600 text-xs rounded-full">Penuh</span>
                            <?php else: ?>
                                <span class="px-2 py-1 bg-green-600 text-xs rounded-full">Tersedia</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>