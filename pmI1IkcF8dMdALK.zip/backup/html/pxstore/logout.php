<?php
// logout.php - Logout dan bersihkan session
require_once 'config.php';

session_start();
session_unset();
session_destroy();

header('Location: login.php');
exit();
?>