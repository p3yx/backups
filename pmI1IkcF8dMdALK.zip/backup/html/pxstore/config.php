<?php
// config.php - Konfigurasi database dan setting
define('DB_PATH', '/root/sellbot/sellvpn.db');
define('SITE_NAME', 'PXSTORE');
define('CURRENCY', 'Rp');

// Koneksi ke database SQLite
function getDB() {
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch(PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Fungsi helper untuk format mata uang
function formatCurrency($amount) {
    return CURRENCY . number_format($amount, 0, ',', '.');
}

// Memeriksa login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Memeriksa role admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Memeriksa role reseller
function isReseller() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'reseller';
}

// Memeriksa saldo user
function getUserBalance($user_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT saldo FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['saldo'] : 0;
}

// Memeriksa status trial user
function hasUnlimitedTrial($user_id) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM unlimited_trial_users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch() !== false;
}

// Memeriksa tombol trial aktif
function isTrialButtonActive() {
    $db = getDB();
    $stmt = $db->prepare("SELECT show_trial_button FROM ui_config WHERE id = 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_trial_button'] == 1;
}

// Memeriksa tombol sewa script aktif
function isSewaScriptButtonActive() {
    $db = getDB();
    $stmt = $db->prepare("SELECT show_sewa_script_button FROM ui_config WHERE id = 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_sewa_script_button'] == 1;
}

// Memeriksa tombol upgrade reseller aktif
function isUpgradeResellerButtonActive() {
    $db = getDB();
    $stmt = $db->prepare("SELECT show_upgrade_reseller_button FROM ui_config WHERE id = 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result && $result['show_upgrade_reseller_button'] == 1;
}

// Mendapatkan diskon reseller
function getResellerDiscount() {
    $db = getDB();
    $stmt = $db->prepare("SELECT discount_percent FROM reseller_config WHERE id = 1");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['discount_percent'] : 0;
}

// Mendapatkan daftar server
function getServers() {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM Server");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Tambahkan fungsi ini di config.php

// Mendapatkan auth key dari server
function getServerAuth($serverId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT auth FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['auth'] : '';
}

// Mendapatkan detail server lengkap
function getServerDetails($serverId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Mendapatkan statistik user
function getUserStats($user_id) {
    $db = getDB();
    
    // Hitung waktu untuk hari ini, minggu ini, bulan ini
    $todayStart = date('Y-m-d 00:00:00');
    $weekStart = date('Y-m-d 00:00:00', strtotime('this week'));
    $monthStart = date('Y-m-01 00:00:00');
    
    $stats = [
        'today' => 0,
        'week' => 0,
        'month' => 0
    ];
    
    // Hitung transaksi hari ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE user_id = ? AND waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$user_id, $todayStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['today'] = $result['count'];
    
    // Hitung transaksi minggu ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE user_id = ? AND waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$user_id, $weekStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['week'] = $result['count'];
    
    // Hitung transaksi bulan ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE user_id = ? AND waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$user_id, $monthStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['month'] = $result['count'];
    
    return $stats;
}

// Mendapatkan statistik global
function getGlobalStats() {
    $db = getDB();
    
    // Hitung waktu untuk hari ini, minggu ini, bulan ini
    $todayStart = date('Y-m-d 00:00:00');
    $weekStart = date('Y-m-d 00:00:00', strtotime('this week'));
    $monthStart = date('Y-m-01 00:00:00');
    
    $stats = [
        'today' => 0,
        'week' => 0,
        'month' => 0,
        'total_users' => 0,
        'total_servers' => 0
    ];
    
    // Hitung transaksi hari ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$todayStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['today'] = $result['count'];
    
    // Hitung transaksi minggu ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$weekStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['week'] = $result['count'];
    
    // Hitung transaksi bulan ini
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM log_penjualan WHERE waktu_transaksi >= ? AND action_type IN ('create','renew')");
    $stmt->execute([$monthStart]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['month'] = $result['count'];
    
    // Hitung total users
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM users");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['total_users'] = $result['count'];
    
    // Hitung total servers
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM Server");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['total_servers'] = $result['count'];
    
    return $stats;
}

// Fungsi untuk mendapatkan harga setelah diskon (jika reseller)
function getDiscountedPrice($originalPrice, $userRole) {
    if ($userRole === 'reseller') {
        $discount = getResellerDiscount();
        return floor($originalPrice * (100 - $discount) / 100);
    }
    return $originalPrice;
}

// Fungsi untuk membuat akun VPN (placeholder - perlu disesuaikan dengan API Anda)
function createVPNAccount($type, $serverId, $username, $password, $expiryDays) {
    // Implementasi pembuatan akun VPN sesuai dengan API yang Anda gunakan
    // Ini adalah placeholder, Anda perlu menyesuaikan dengan API sebenarnya
    
    $db = getDB();
    
    // Dapatkan detail server
    $stmt = $db->prepare("SELECT * FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    $server = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$server) {
        return ['success' => false, 'message' => 'Server tidak ditemukan'];
    }
    
    // Cek apakah server penuh
    if ($server['total_create_akun'] >= $server['batas_create_akun']) {
        return ['success' => false, 'message' => 'Server penuh, tidak dapat membuat akun'];
    }
    
    // Hitung harga
    $originalPrice = $server['harga'] * $expiryDays;
    $finalPrice = getDiscountedPrice($originalPrice, $_SESSION['role']);
    
    // Cek saldo user
    $userBalance = getUserBalance($_SESSION['user_id']);
    if ($userBalance < $finalPrice) {
        return ['success' => false, 'message' => 'Saldo tidak cukup. Saldo Anda: ' . formatCurrency($userBalance) . ', Diperlukan: ' . formatCurrency($finalPrice)];
    }
    
    // Panggil API pembuatan akun (contoh placeholder)
    // $result = callYourVPNCreateAPI($type, $server, $username, $password, $expiryDays);
    
    // Untuk contoh, kita asumsikan berhasil
    $result = ['success' => true, 'account_details' => 'Detail akun VPN akan ditampilkan di sini'];
    
    if ($result['success']) {
        // Kurangi saldo user
        $stmt = $db->prepare("UPDATE users SET saldo = saldo - ? WHERE user_id = ?");
        $stmt->execute([$finalPrice, $_SESSION['user_id']]);
        
        // Update total akun di server
        $stmt = $db->prepare("UPDATE Server SET total_create_akun = total_create_akun + 1 WHERE id = ?");
        $stmt->execute([$serverId]);
        
        // Catat transaksi
        $stmt = $db->prepare("INSERT INTO log_penjualan (user_id, username, nama_server, tipe_akun, harga, masa_aktif_hari, waktu_transaksi, action_type, user_role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            $_SESSION['username'],
            $server['nama_server'],
            $type,
            $finalPrice,
            $expiryDays,
            date('Y-m-d H:i:s'),
            'create',
            $_SESSION['role']
        ]);
        
        return ['success' => true, 'message' => 'Akun berhasil dibuat!', 'details' => $result['account_details']];
    } else {
        return ['success' => false, 'message' => 'Gagal membuat akun: ' . $result['error']];
    }
}

// Fungsi untuk trial akun (placeholder)
function createTrialAccount($type, $serverId) {
    // Implementasi trial akun VPN sesuai dengan API yang Anda gunakan
    // Ini adalah placeholder, Anda perlu menyesuaikan dengan API sebenarnya
    
    $db = getDB();
    
    // Cek apakah user sudah trial hari ini
    $today = date('Y-m-d');
    $stmt = $db->prepare("SELECT count FROM TrialLog WHERE user_id = ? AND date = ?");
    $stmt->execute([$_SESSION['user_id'], $today]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $trialCount = $result ? $result['count'] : 0;
    
    // Jika bukan unlimited trial dan sudah trial 2x hari ini
    if (!hasUnlimitedTrial($_SESSION['user_id']) && $trialCount >= 2 && !isAdmin()) {
        return ['success' => false, 'message' => 'Anda sudah trial 2x hari ini. Silakan order akun reguler.'];
    }
    
    // Dapatkan detail server
    $stmt = $db->prepare("SELECT * FROM Server WHERE id = ?");
    $stmt->execute([$serverId]);
    $server = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$server) {
        return ['success' => false, 'message' => 'Server tidak ditemukan'];
    }
    
    // Cek apakah server penuh
    if ($server['total_create_akun'] >= $server['batas_create_akun']) {
        return ['success' => false, 'message' => 'Server penuh, tidak dapat membuat trial'];
    }
    
    // Panggil API trial (contoh placeholder)
    // $result = callYourVPNTrialAPI($type, $server);
    
    // Untuk contoh, kita asumsikan berhasil
    $result = ['success' => true, 'account_details' => 'Detail trial VPN akan ditampilkan di sini'];
    
    if ($result['success']) {
        // Update total akun di server
        $stmt = $db->prepare("UPDATE Server SET total_create_akun = total_create_akun + 1 WHERE id = ?");
        $stmt->execute([$serverId]);
        
        // Update trial count
        if (!hasUnlimitedTrial($_SESSION['user_id']) && !isAdmin()) {
            $newCount = $trialCount + 1;
            $stmt = $db->prepare("INSERT OR REPLACE INTO TrialLog (user_id, date, count) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $today, $newCount]);
        }
        
        return ['success' => true, 'message' => 'Trial berhasil dibuat!', 'details' => $result['account_details']];
    } else {
        return ['success' => false, 'message' => 'Gagal membuat trial: ' . $result['error']];
    }
}

session_start();
?>