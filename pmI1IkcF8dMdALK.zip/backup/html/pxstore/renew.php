<?php
// renew.php - Halaman renew akun VPN
require_once 'header.php';

// Ambil daftar server
$servers = getServers();

// Proses renew akun
$message = '';
$messageType = '';
$authKey = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['server_id']) && isset($_POST['days'])) {
    $username = $_POST['username'];
    $serverId = $_POST['server_id'];
    $days = intval($_POST['days']);
    
    // Validasi input
    if (empty($username) || $days <= 0) {
        $message = 'Username dan masa aktif harus diisi dengan benar';
        $messageType = 'error';
    } else {
        // Dapatkan auth key dari server yang dipilih
        $authKey = getServerAuth($serverId);
        
        // Tentukan jenis layanan berdasarkan input
        $type = $_POST['type'] ?? 'ssh';
        
        $result = renewVPNAccount($type, $serverId, $username, $days, $authKey);
        
        if ($result['success']) {
            $message = $result['message'];
            $messageType = 'success';
            
            // Tambahkan detail akun ke message
            if (isset($result['details'])) {
                $message .= "\n\n" . $result['details'];
            }
        } else {
            $message = $result['message'];
            $messageType = 'error';
        }
    }
}

// Fungsi untuk renew akun VPN
function renewVPNAccount($type, $serverId, $username, $days, $authKey) {
    $db = getDB();
    
    // Dapatkan detail server
    $server = getServerDetails($serverId);
    
    if (!$server) {
        return ['success' => false, 'message' => 'Server tidak ditemukan'];
    }
    
    // Hitung harga
    $originalPrice = $server['harga'] * $days;
    $finalPrice = getDiscountedPrice($originalPrice, $_SESSION['role']);
    
    // Cek saldo user
    $userBalance = getUserBalance($_SESSION['user_id']);
    if ($userBalance < $finalPrice) {
        return ['success' => false, 'message' => 'Saldo tidak cukup. Saldo Anda: ' . formatCurrency($userBalance) . ', Diperlukan: ' . formatCurrency($finalPrice)];
    }
    
    // Panggil API renew akun dengan auth key
    // $result = callYourVPNRenewAPI($type, $server, $username, $days, $authKey);
    
    // Untuk contoh, kita asumsikan berhasil
    $result = ['success' => true, 'account_details' => 'Detail akun VPN akan ditampilkan di sini'];
    
    if ($result['success']) {
        // Kurangi saldo user
        $stmt = $db->prepare("UPDATE users SET saldo = saldo - ? WHERE user_id = ?");
        $stmt->execute([$finalPrice, $_SESSION['user_id']]);
        
        // Catat transaksi
        $stmt = $db->prepare("INSERT INTO log_penjualan (user_id, username, nama_server, tipe_akun, harga, masa_aktif_hari, waktu_transaksi, action_type, user_role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            $_SESSION['username'],
            $server['nama_server'],
            $type,
            $finalPrice,
            $days,
            date('Y-m-d H:i:s'),
            'renew',
            $_SESSION['role']
        ]);
        
        return ['success' => true, 'message' => 'Akun berhasil diperpanjang!', 'details' => $result['account_details']];
    } else {
        return ['success' => false, 'message' => 'Gagal memperpanjang akun: ' . $result['error']];
    }
}
?>

<div class="animate-fade-in">
    <!-- Header -->
    <div class="card p-6 mb-6 bg-gradient-to-r from-green-900 to-blue-900">
        <div class="flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold">Renew Akun VPN</h2>
                <p class="text-green-200">Perpanjang masa aktif akun VPN Anda</p>
            </div>
            <div class="mt-4 md:mt-0 flex items-center space-x-2 bg-green-800 bg-opacity-50 px-4 py-2 rounded-lg">
                <i class="fas fa-wallet text-green-400"></i>
                <span class="font-semibold">Saldo: <?php echo formatCurrency(getUserBalance($_SESSION['user_id'])); ?></span>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
    <div class="card p-4 mb-6 <?php echo $messageType === 'success' ? 'bg-green-900' : 'bg-red-900'; ?>">
        <div class="flex items-center">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span><?php echo nl2br(htmlspecialchars($message)); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Info Auth Key (jika tersedia) -->
    <?php if (!empty($authKey)): ?>
    <div class="card p-4 mb-6 bg-blue-900">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="font-semibold text-blue-300">Auth Key Server:</h3>
                <p class="text-sm font-mono bg-gray-800 p-2 rounded mt-2"><?php echo htmlspecialchars($authKey); ?></p>
            </div>
            <button onclick="copyAuthKey()" class="bg-blue-700 hover:bg-blue-600 px-3 py-1 rounded">
                <i class="fas fa-copy"></i> Salin
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Form Renew -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-sync-alt mr-2 text-green-400"></i> Form Renew Akun
        </h2>
        
        <form method="POST">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-400 mb-2" for="username">Username Akun</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500" 
                        placeholder="Masukkan username akun yang akan diperpanjang"
                        required
                    >
                </div>
                
                <div>
                    <label class="block text-gray-400 mb-2" for="days">Masa Aktif (Hari)</label>
                    <input 
                        type="number" 
                        id="days" 
                        name="days" 
                        min="1" 
                        max="365" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500" 
                        placeholder="Jumlah hari"
                        required
                        value="30"
                    >
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-400 mb-2" for="type">Jenis Layanan</label>
                <select 
                    id="type" 
                    name="type" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                    <option value="ssh">SSH</option>
                    <option value="vmess">VMESS</option>
                    <option value="vless">VLESS</option>
                    <option value="trojan">Trojan</option>
                    <option value="shadowsocks">Shadowsocks</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-400 mb-2" for="server_id">Pilih Server</label>
                <select 
                    id="server_id" 
                    name="server_id" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                    onchange="showAuthKey(this)"
                >
                    <option value="">-- Pilih Server --</option>
                    <?php foreach ($servers as $server): 
                        $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                        $hargaPerHari = getDiscountedPrice($server['harga'], $_SESSION['role']);
                        $authKey = getServerAuth($server['id']);
                    ?>
                    <option value="<?php echo $server['id']; ?>" 
                            data-auth="<?php echo htmlspecialchars($authKey); ?>"
                            <?php echo $isFull ? 'disabled' : ''; ?>>
                        <?php echo htmlspecialchars($server['nama_server']); ?> - 
                        <?php echo formatCurrency($hargaPerHari); ?>/hari
                        <?php echo $isFull ? ' (Penuh)' : ''; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Auth Key Display -->
            <div id="authKeySection" class="bg-gray-800 p-4 rounded mb-4 hidden">
                <h3 class="font-semibold mb-2 text-blue-300">Auth Key Server Terpilih:</h3>
                <div class="flex items-center justify-between">
                    <p id="authKeyDisplay" class="font-mono bg-gray-700 p-2 rounded flex-1"></p>
                    <button type="button" onclick="copyAuthKey()" class="bg-blue-600 hover:bg-blue-500 px-3 py-2 rounded ml-2">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
            </div>
            
            <div class="bg-gray-800 p-4 rounded mb-4">
                <h3 class="font-semibold mb-2">Estimasi Biaya</h3>
                <div id="priceEstimation" class="text-lg font-semibold text-green-400">
                    Pilih server dan masa aktif untuk melihat estimasi biaya
                </div>
            </div>
            
            <button type="submit" class="btn-primary px-4 py-2 rounded font-semibold bg-green-600 hover:bg-green-700">
                <i class="fas fa-sync-alt mr-2"></i> Renew Akun
            </button>
        </form>
    </div>

    <!-- Daftar Server -->
    <div class="card p-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-server mr-2 text-green-400"></i> Daftar Server Tersedia
        </h2>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-700">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Nama Server</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Auth Key</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Harga/Hari</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php foreach ($servers as $server): 
                        $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                        $hargaPerHari = getDiscountedPrice($server['harga'], $_SESSION['role']);
                        $authKey = getServerAuth($server['id']);
                    ?>
                    <tr>
                        <td class="px-4 py-3"><?php echo htmlspecialchars($server['nama_server']); ?></td>
                        <td class="px-4 py-3 font-mono text-xs"><?php echo substr($authKey, 0, 15); ?>...</td>
                        <td class="px-4 py-3"><?php echo formatCurrency($hargaPerHari); ?></td>
                        <td class="px-4 py-3">
                            <?php if ($isFull): ?>
                                <span class="px-2 py-1 bg-red-600 text-xs rounded-full">Penuh</span>
                            <?php else: ?>
                                <span class="px-2 py-1 bg-green-600 text-xs rounded-full">Tersedia</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Hitung estimasi harga berdasarkan pilihan server dan hari
    function calculatePrice() {
        const serverSelect = document.getElementById('server_id');
        const daysInput = document.getElementById('days');
        const priceDisplay = document.getElementById('priceEstimation');
        
        if (serverSelect.value && daysInput.value) {
            const selectedOption = serverSelect.options[serverSelect.selectedIndex];
            const priceText = selectedOption.text.split(' - ')[1].split('/hari')[0].trim();
            const pricePerDay = parseInt(priceText.replace(/[^\d]/g, ''));
            const days = parseInt(daysInput.value);
            const totalPrice = pricePerDay * days;
            
            priceDisplay.textContent = 'Rp ' + totalPrice.toLocaleString('id-ID');
        } else {
            priceDisplay.textContent = 'Pilih server dan masa aktif untuk melihat estimasi biaya';
        }
    }
    
    // Tampilkan auth key saat server dipilih
    function showAuthKey(select) {
        const authKeySection = document.getElementById('authKeySection');
        const authKeyDisplay = document.getElementById('authKeyDisplay');
        
        if (select.value) {
            const selectedOption = select.options[select.selectedIndex];
            const authKey = selectedOption.getAttribute('data-auth');
            
            authKeyDisplay.textContent = authKey;
            authKeySection.classList.remove('hidden');
        } else {
            authKeySection.classList.add('hidden');
        }
        
        calculatePrice();
    }
    
    // Fungsi untuk copy auth key
    function copyAuthKey() {
        const authKey = document.getElementById('authKeyDisplay').textContent;
        navigator.clipboard.writeText(authKey).then(() => {
            alert('Auth key berhasil disalin!');
        }).catch(err => {
            console.error('Gagal menyalin auth key:', err);
        });
    }
    
    // Event listeners
    document.getElementById('server_id').addEventListener('change', function() {
        showAuthKey(this);
    });
    document.getElementById('days').addEventListener('input', calculatePrice);
    
    // Hitung harga awal
    calculatePrice();
</script>

<?php
require_once 'footer.php';
?>