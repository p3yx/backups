<?php
// login.php - Halaman login
require_once 'config.php';

// Jika sudah login, redirect ke index
if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

// Proses login
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? '';
    $password = $_POST['password'] ?? ''; // Password bisa berupa ID Telegram atau metode auth lainnya
    
    // Validasi input
    if (empty($user_id)) {
        $error = 'User ID harus diisi';
    } else {
        $db = getDB();
        
        // Cek apakah user ada di database
        $stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Untuk demo, kita asumsikan login berhasil dengan user ID saja
            // Di production, Anda perlu menambahkan verifikasi password/telegram
            
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = 'User_' . $user['user_id']; // Ganti dengan username sebenarnya
            $_SESSION['role'] = $user['role'];
            
            header('Location: index.php');
            exit();
        } else {
            $error = 'User ID tidak ditemukan';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-primary: #1a202c;
            --bg-secondary: #2d3748;
            --text-primary: #e2e8f0;
            --text-secondary: #a0aec0;
            --accent: #4299e1;
        }
        
        body {
            background-color: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Inter', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-card {
            background-color: var(--bg-secondary);
            border-radius: 0.75rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            width: 100%;
            max-width: 400px;
            padding: 2rem;
        }
        
        .btn-primary {
            background-color: var(--accent);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background-color: #3182ce;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-6">
            <i class="fas fa-shield-alt text-blue-400 text-5xl mb-3"></i>
            <h1 class="text-2xl font-bold"><?php echo SITE_NAME; ?></h1>
            <p class="text-gray-400">Login untuk mengakses panel VPN</p>
        </div>
        
        <?php if (!empty($error)): ?>
        <div class="bg-red-800 text-red-200 p-3 rounded mb-4">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-400 mb-2" for="user_id">User ID</label>
                <input 
                    type="text" 
                    id="user_id" 
                    name="user_id" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" 
                    placeholder="Masukkan User ID Anda"
                    required
                >
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-400 mb-2" for="password">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" 
                    placeholder="Masukkan password"
                    required
                >
            </div>
            
            <button type="submit" class="btn-primary w-full py-2 rounded font-semibold">
                <i class="fas fa-sign-in-alt mr-2"></i> Login
            </button>
        </form>
        
        <div class="mt-6 text-center text-sm text-gray-500">
            <p>Belum punya akun? Hubungi admin untuk mendaftar</p>
        </div>
    </div>
</body>
</html>