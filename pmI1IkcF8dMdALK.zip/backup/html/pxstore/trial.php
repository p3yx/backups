<?php
// trial.php - Halaman trial akun VPN
require_once 'header.php';

// Cek apakah user boleh akses trial
$bolehTrial = isTrialButtonActive() || hasUnlimitedTrial($_SESSION['user_id']) || isAdmin();
if (!$bolehTrial) {
    header('Location: index.php');
    exit();
}

// Ambil daftar server
$servers = getServers();

// Proses pembuatan trial
$message = '';
$messageType = '';
$authKey = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['server_id']) && isset($_POST['type'])) {
    $serverId = $_POST['server_id'];
    $type = $_POST['type'];
    
    // Dapatkan auth key dari server yang dipilih
    $authKey = getServerAuth($serverId);
    
    $result = createTrialAccount($type, $serverId, $authKey);
    
    if ($result['success']) {
        $message = $result['message'];
        $messageType = 'success';
        
        // Tambahkan detail akun ke message
        if (isset($result['details'])) {
            $message .= "\n\n" . $result['details'];
        }
    } else {
        $message = $result['message'];
        $messageType = 'error';
    }
}

// Cek trial count untuk hari ini
$today = date('Y-m-d');
$db = getDB();
$stmt = $db->prepare("SELECT count FROM TrialLog WHERE user_id = ? AND date = ?");
$stmt->execute([$_SESSION['user_id'], $today]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$trialCount = $result ? $result['count'] : 0;
$trialLimit = hasUnlimitedTrial($_SESSION['user_id']) || isAdmin() ? 'Unlimited' : 2;
?>

<div class="animate-fade-in">
    <!-- Header -->
    <div class="card p-6 mb-6 bg-gradient-to-r from-blue-900 to-purple-900">
        <div class="flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold">Trial Akun VPN</h2>
                <p class="text-blue-200">Coba layanan VPN kami secara gratis</p>
            </div>
            <div class="mt-4 md:mt-0 flex items-center space-x-2 bg-blue-800 bg-opacity-50 px-4 py-2 rounded-lg">
                <i class="fas fa-vial text-blue-400"></i>
                <span class="font-semibold">Trial Hari Ini: <?php echo $trialCount; ?>/<?php echo $trialLimit; ?></span>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
    <div class="card p-4 mb-6 <?php echo $messageType === 'success' ? 'bg-green-900' : 'bg-red-900'; ?>">
        <div class="flex items-center">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span><?php echo nl2br(htmlspecialchars($message)); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Info Auth Key (jika tersedia) -->
    <?php if (!empty($authKey)): ?>
    <div class="card p-4 mb-6 bg-blue-900">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="font-semibold text-blue-300">Auth Key Server:</h3>
                <p class="text-sm font-mono bg-gray-800 p-2 rounded mt-2"><?php echo htmlspecialchars($authKey); ?></p>
            </div>
            <button onclick="copyAuthKey()" class="bg-blue-700 hover:bg-blue-600 px-3 py-1 rounded">
                <i class="fas fa-copy"></i> Salin
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Pilihan Jenis VPN -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-network-wired mr-2 text-blue-400"></i> Pilih Jenis VPN
        </h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <!-- SSH -->
            <div class="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition cursor-pointer" onclick="selectType('ssh')">
                <div class="flex items-center mb-2">
                    <i class="fas fa-terminal text-green-400 text-2xl mr-2"></i>
                    <h3 class="font-semibold">SSH</h3>
                </div>
                <p class="text-sm text-gray-300">Secure Shell untuk akses remote yang aman</p>
            </div>
            
            <!-- VMESS -->
            <div class="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition cursor-pointer" onclick="selectType('vmess')">
                <div class="flex items-center mb-2">
                    <i class="fas fa-bolt text-yellow-400 text-2xl mr-2"></i>
                    <h3 class="font-semibold">VMESS</h3>
                </div>
                <p class="text-sm text-gray-300">Protokol VPN yang cepat dan andal</p>
            </div>
            
            <!-- VLESS -->
            <div class="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition cursor-pointer" onclick="selectType('vless')">
                <div class="flex items-center mb-2">
                    <i class="fas fa-tachometer-alt text-purple-400 text-2xl mr-2"></i>
                    <h3 class="font-semibold">VLESS</h3>
                </div>
                <p class="text-sm text-gray-300">Versi ringan dari VMESS tanpa encryption</p>
            </div>
            
            <!-- Trojan -->
            <div class="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition cursor-pointer" onclick="selectType('trojan')">
                <div class="flex items-center mb-2">
                    <i class="fas fa-user-secret text-red-400 text-2xl mr-2"></i>
                    <h3 class="font-semibold">Trojan</h3>
                </div>
                <p class="text-sm text-gray-300">Protokol yang menyamar sebagai traffic HTTPS</p>
            </div>
            
            <!-- Shadowsocks -->
            <div class="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition cursor-pointer" onclick="selectType('shadowsocks')">
                <div class="flex items-center mb-2">
                    <i class="fas fa-shield-alt text-blue-400 text-2xl mr-2"></i>
                    <h3 class="font-semibold">Shadowsocks</h3>
                </div>
                <p class="text-sm text-gray-300">Protokol proxy yang ringan dan efisien</p>
            </div>
        </div>
    </div>

    <!-- Form Pilihan Server (akan muncul setelah memilih jenis VPN) -->
    <div id="serverSelection" class="card p-6 mb-6 hidden">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-server mr-2 text-blue-400"></i> Pilih Server
        </h2>
        
        <form method="POST" id="trialForm">
            <input type="hidden" name="type" id="selectedType">
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($servers as $server): 
                    $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                    $authKey = getServerAuth($server['id']);
                ?>
                <div class="server-option bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition <?php echo $isFull ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'; ?>"
                     data-server-id="<?php echo $server['id']; ?>"
                     data-full="<?php echo $isFull ? 'true' : 'false'; ?>"
                     data-auth="<?php echo htmlspecialchars($authKey); ?>">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="font-semibold"><?php echo htmlspecialchars($server['nama_server']); ?></h3>
                        <?php if ($isFull): ?>
                            <span class="bg-red-600 px-2 py-1 rounded text-xs">Penuh</span>
                        <?php else: ?>
                            <span class="bg-green-600 px-2 py-1 rounded text-xs">Tersedia</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-sm text-gray-300 mb-2">Domain: <?php echo htmlspecialchars($server['domain']); ?></p>
                    <p class="text-sm text-blue-300 mb-2 font-mono truncate" title="Auth: <?php echo htmlspecialchars($authKey); ?>">
                        Auth: <?php echo substr($authKey, 0, 15); ?>...
                    </p>
                    <div class="flex justify-between text-xs">
                        <span>Quota: <?php echo $server['quota']; ?>GB</span>
                        <span>IP Limit: <?php echo $server['iplimit']; ?></span>
                    </div>
                    <div class="mt-2 text-xs">
                        <span>Akun: <?php echo $server['total_create_akun']; ?>/<?php echo $server['batas_create_akun']; ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <input type="hidden" name="server_id" id="selectedServer">
            
            <div class="mt-6 flex justify-end">
                <button type="submit" id="createTrialBtn" class="btn-primary px-4 py-2 rounded font-semibold disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                    <i class="fas fa-plus-circle mr-2"></i> Buat Trial Akun
                </button>
            </div>
        </form>
    </div>

    <!-- Informasi Trial -->
    <div class="card p-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-info-circle mr-2 text-blue-400"></i> Informasi Trial
        </h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="bg-gray-700 p-4 rounded-lg">
                <h3 class="font-semibold mb-2 text-green-400">Keuntungan Trial</h3>
                <ul class="list-disc list-inside text-sm space-y-1">
                    <li>Gratis tanpa biaya</li>
                    <li>Masa aktif 1 hari</li>
                    <li>Quota 1GB</li>
                    <li>Limit 1 IP</li>
                    <li>Bisa testing semua jenis VPN</li>
                </ul>
            </div>
            
            <div class="bg-gray-700 p-4 rounded-lg">
                <h3 class="font-semibold mb-2 text-red-400">Batasan Trial</h3>
                <ul class="list-disc list-inside text-sm space-y-1">
                    <li>Maksimal 2 trial per hari</li>
                    <li>Tidak bisa renew</li>
                    <li>Speed mungkin terbatas</li>
                    <li>Server prioritas untuk user berbayar</li>
                </ul>
            </div>
        </div>
        
        <?php if (hasUnlimitedTrial($_SESSION['user_id']) || isAdmin()): ?>
        <div class="mt-4 bg-blue-900 p-4 rounded-lg">
            <h3 class="font-semibold mb-2 text-yellow-400">⭐ Akses Khusus</h3>
            <p class="text-sm">Anda memiliki akses trial unlimited! Nikmati fitur trial tanpa batasan.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
    let selectedType = '';
    let selectedServer = '';
    let selectedAuth = '';
    
    function selectType(type) {
        selectedType = type;
        document.getElementById('selectedType').value = type;
        document.getElementById('serverSelection').classList.remove('hidden');
        
        // Scroll ke bagian pemilihan server
        document.getElementById('serverSelection').scrollIntoView({ behavior: 'smooth' });
    }
    
    // Event listener untuk pemilihan server
    document.querySelectorAll('.server-option').forEach(option => {
        option.addEventListener('click', function() {
            const isFull = this.getAttribute('data-full') === 'true';
            
            if (!isFull) {
                // Hapus seleksi sebelumnya
                document.querySelectorAll('.server-option').forEach(opt => {
                    opt.classList.remove('ring-2', 'ring-blue-500');
                });
                
                // Tambahkan seleksi ke server yang dipilih
                this.classList.add('ring-2', 'ring-blue-500');
                
                selectedServer = this.getAttribute('data-server-id');
                selectedAuth = this.getAttribute('data-auth');
                document.getElementById('selectedServer').value = selectedServer;
                
                // Tampilkan auth key
                document.getElementById('authKeyDisplay').textContent = selectedAuth;
                document.getElementById('authKeySection').classList.remove('hidden');
                
                // Aktifkan tombol buat trial
                document.getElementById('createTrialBtn').disabled = false;
            }
        });
    });
    
    // Validasi form sebelum submit
    document.getElementById('trialForm').addEventListener('submit', function(e) {
        if (!selectedType || !selectedServer) {
            e.preventDefault();
            alert('Silakan pilih jenis VPN dan server terlebih dahulu');
        }
    });
    
    // Fungsi untuk copy auth key
    function copyAuthKey() {
        navigator.clipboard.writeText(selectedAuth).then(() => {
            alert('Auth key berhasil disalin!');
        }).catch(err => {
            console.error('Gagal menyalin auth key:', err);
        });
    }
</script>

<?php
require_once 'footer.php';
?>