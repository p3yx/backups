<?php
// topup.php - Halaman top up saldo
require_once 'header.php';

// Proses top up
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
    $amount = intval($_POST['amount']);
    
    // Validasi input
    if ($amount < 10000) {
        $message = 'Minimum top up adalah Rp 10.000';
        $messageType = 'error';
    } else {
        // Proses top up
        $db = getDB();
        
        try {
            // Tambah saldo user
            $stmt = $db->prepare("UPDATE users SET saldo = saldo + ? WHERE user_id = ?");
            $stmt->execute([$amount, $_SESSION['user_id']]);
            
            // Catat transaksi top up
            $stmt = $db->prepare("INSERT INTO topup_log (user_id, username, amount, method, waktu) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['username'],
                $amount,
                'Manual',
                date('Y-m-d H:i:s')
            ]);
            
            $message = 'Top up berhasil! Saldo Anda telah ditambahkan sebesar ' . formatCurrency($amount);
            $messageType = 'success';
            
        } catch (Exception $e) {
            $message = 'Terjadi kesalahan: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}

// Ambil riwayat top up
$db = getDB();
$stmt = $db->prepare("SELECT * FROM topup_log WHERE user_id = ? ORDER BY id DESC LIMIT 5");
$stmt->execute([$_SESSION['user_id']]);
$topupHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="animate-fade-in">
    <!-- Header -->
    <div class="card p-6 mb-6 bg-gradient-to-r from-purple-900 to-pink-900">
        <div class="flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold">Top Up Saldo</h2>
                <p class="text-purple-200">Isi saldo akun Anda untuk pembelian layanan VPN</p>
            </div>
            <div class="mt-4 md:mt-0 flex items-center space-x-2 bg-purple-800 bg-opacity-50 px-4 py-2 rounded-lg">
                <i class="fas fa-wallet text-green-400"></i>
                <span class="font-semibold">Saldo: <?php echo formatCurrency(getUserBalance($_SESSION['user_id'])); ?></span>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
    <div class="card p-4 mb-6 <?php echo $messageType === 'success' ? 'bg-green-900' : 'bg-red-900'; ?>">
        <div class="flex items-center">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span><?php echo nl2br(htmlspecialchars($message)); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Form Top Up -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-money-bill-wave mr-2 text-purple-400"></i> Isi Saldo
        </h2>
        
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-400 mb-2" for="amount">Jumlah Top Up</label>
                <input 
                    type="number" 
                    id="amount" 
                    name="amount" 
                    min="10000" 
                    step="1000" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500" 
                    placeholder="Minimal Rp 10.000"
                    required
                >
                <p class="text-xs text-gray-500 mt-1">Minimum top up: Rp 10.000</p>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-400 mb-2">Metode Pembayaran</label>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <div class="bg-gray-700 p-3 rounded flex items-center">
                        <i class="fas fa-qrcode text-blue-400 mr-2"></i>
                        <span>QRIS</span>
                    </div>
                    <div class="bg-gray-700 p-3 rounded flex items-center">
                        <i class="fas fa-university text-green-400 mr-2"></i>
                        <span>Transfer Bank</span>
                    </div>
                    <div class="bg-gray-700 p-3 rounded flex items-center">
                        <i class="fas fa-mobile-alt text-yellow-400 mr-2"></i>
                        <span>E-Wallet</span>
                    </div>
                    <div class="bg-gray-700 p-3 rounded flex items-center">
                        <i class="fas fa-store text-red-400 mr-2"></i>
                        <span>Alfamart/Indomaret</span>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn-primary px-4 py-2 rounded font-semibold bg-purple-600 hover:bg-purple-700">
                <i class="fas fa-credit-card mr-2"></i> Proses Top Up
            </button>
        </form>
    </div>

    <!-- Paket Top Up -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-boxes mr-2 text-purple-400"></i> Paket Top Up
        </h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-gray-700 p-4 rounded-lg text-center cursor-pointer hover:bg-gray-600 transition" onclick="setAmount(10000)">
                <div class="text-2xl font-bold text-green-400 mb-2">Rp 10.000</div>
                <p class="text-sm text-gray-300">Paket Basic</p>
            </div>
            
            <div class="bg-gray-700 p-4 rounded-lg text-center cursor-pointer hover:bg-gray-600 transition" onclick="setAmount(50000)">
                <div class="text-2xl font-bold text-blue-400 mb-2">Rp 50.000</div>
                <p class="text-sm text-gray-300">Paket Standard</p>
            </div>
            
            <div class="bg-gray-700 p-4 rounded-lg text-center cursor-pointer hover:bg-gray-600 transition" onclick="setAmount(100000)">
                <div class="text-2xl font-bold text-purple-400 mb-2">Rp 100.000</div>
                <p class="text-sm text-gray-300">Paket Premium</p>
            </div>
            
            <div class="bg-gray-700 p-4 rounded-lg text-center cursor-pointer hover:bg-gray-600 transition" onclick="setAmount(200000)">
                <div class="text-2xl font-bold text-yellow-400 mb-2">Rp 200.000</div>
                <p class="text-sm text-gray-300">Paket VIP</p>
            </div>
        </div>
    </div>

    <!-- Riwayat Top Up -->
    <div class="card p-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-history mr-2 text-purple-400"></i> Riwayat Top Up
        </h2>
        
        <?php if (count($topupHistory) > 0): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-700">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Tanggal</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Jumlah</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Metode</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php foreach ($topupHistory as $history): ?>
                    <tr>
                        <td class="px-4 py-3"><?php echo date('d M Y H:i', strtotime($history['waktu'])); ?></td>
                        <td class="px-4 py-3 text-green-400"><?php echo formatCurrency($history['amount']); ?></td>
                        <td class="px-4 py-3"><?php echo htmlspecialchars($history['method']); ?></td>
                        <td class="px-4 py-3">
                            <span class="px-2 py-1 bg-green-600 text-xs rounded-full">Berhasil</span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p class="text-gray-400 text-center py-4">Belum ada riwayat top up</p>
        <?php endif; ?>
    </div>
</div>

<script>
    function setAmount(amount) {
        document.getElementById('amount').value = amount;
    }
</script>

<?php
require_once 'footer.php';
?>