<?php
// footer.php - Footer untuk semua halaman
?>
        </main>
    </div>

    <!-- Mobile Bottom Navigation -->
    <?php if (isLoggedIn()): ?>
    <nav class="md:hidden fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 flex justify-around py-2">
        <a href="index.php" class="flex flex-col items-center text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'text-blue-400' : 'text-gray-400'; ?>">
            <i class="fas fa-home text-lg"></i>
            <span>Home</span>
        </a>
        
        <a href="create.php" class="flex flex-col items-center text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'create.php' ? 'text-blue-400' : 'text-gray-400'; ?>">
            <i class="fas fa-plus-circle text-lg"></i>
            <span>Buat</span>
        </a>
        
        <a href="topup.php" class="flex flex-col items-center text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'topup.php' ? 'text-blue-400' : 'text-gray-400'; ?>">
            <i class="fas fa-money-bill-wave text-lg"></i>
            <span>Top Up</span>
        </a>
        
        <a href="profile.php" class="flex flex-col items-center text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'text-blue-400' : 'text-gray-400'; ?>">
            <i class="fas fa-user text-lg"></i>
            <span>Profile</span>
        </a>
    </nav>
    <?php endif; ?>

    <script>
        // Toggle mobile menu
        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        }
        
        // Alert otomatis hilang setelah 5 detik
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert-auto-dismiss');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.transition = 'opacity 0.5s ease-out';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                }, 5000);
            });
        });
    </script>
</body>
</html>