<?php
// create.php - Halaman buat akun VPN
require_once 'header.php';

// Ambil daftar server
$servers = getServers();

// Proses pembuatan akun
$message = '';
$messageType = '';
$authKey = '';
$accountDetails = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['server_id']) && isset($_POST['days'])) {
    $username = $_POST['username'];
    $serverId = $_POST['server_id'];
    $days = intval($_POST['days']);
    $password = $_POST['password'] ?? '';
    $type = $_POST['type'] ?? 'ssh';
    
    // Validasi input
    if (empty($username) || $days <= 0) {
        $message = 'Username dan masa aktif harus diisi dengan benar';
        $messageType = 'error';
    } else {
        // Dapatkan auth key dari server yang dipilih
        $authKey = getServerAuth($serverId);
        
        $result = createVPNAccount($type, $serverId, $username, $password, $days, $authKey);
        
        if ($result['success']) {
            $message = $result['message'];
            $messageType = 'success';
            $accountDetails = $result['details'] ?? '';
        } else {
            $message = $result['message'];
            $messageType = 'error';
        }
    }
}

// Fungsi untuk membuat akun VPN
function createVPNAccount($type, $serverId, $username, $password, $expiryDays, $authKey) {
    $db = getDB();
    
    // Dapatkan detail server
    $server = getServerDetails($serverId);
    
    if (!$server) {
        return ['success' => false, 'message' => 'Server tidak ditemukan'];
    }
    
    // Cek apakah server penuh
    if ($server['total_create_akun'] >= $server['batas_create_akun']) {
        return ['success' => false, 'message' => 'Server penuh, tidak dapat membuat akun'];
    }
    
    // Generate password jika kosong (kecuali untuk SSH)
    if (empty($password) && $type !== 'ssh') {
        $password = generateRandomPassword();
    }
    
    // Hitung harga
    $originalPrice = $server['harga'] * $expiryDays;
    $finalPrice = getDiscountedPrice($originalPrice, $_SESSION['role']);
    
    // Cek saldo user
    $userBalance = getUserBalance($_SESSION['user_id']);
    if ($userBalance < $finalPrice) {
        return ['success' => false, 'message' => 'Saldo tidak cukup. Saldo Anda: ' . formatCurrency($userBalance) . ', Diperlukan: ' . formatCurrency($finalPrice)];
    }
    
    // Panggil API pembuatan akun dengan auth key
    // $result = callYourVPNCreateAPI($type, $server, $username, $password, $expiryDays, $authKey);
    
    // Untuk contoh, kita asumsikan berhasil
    $accountDetails = generateAccountDetails($type, $username, $password, $server, $expiryDays);
    $result = ['success' => true, 'account_details' => $accountDetails];
    
    if ($result['success']) {
        // Kurangi saldo user
        $stmt = $db->prepare("UPDATE users SET saldo = saldo - ? WHERE user_id = ?");
        $stmt->execute([$finalPrice, $_SESSION['user_id']]);
        
        // Update total akun di server
        $stmt = $db->prepare("UPDATE Server SET total_create_akun = total_create_akun + 1 WHERE id = ?");
        $stmt->execute([$serverId]);
        
        // Catat transaksi
        $stmt = $db->prepare("INSERT INTO log_penjualan (user_id, username, nama_server, tipe_akun, harga, masa_aktif_hari, waktu_transaksi, action_type, user_role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_SESSION['user_id'],
            $_SESSION['username'],
            $server['nama_server'],
            $type,
            $finalPrice,
            $expiryDays,
            date('Y-m-d H:i:s'),
            'create',
            $_SESSION['role']
        ]);
        
        return ['success' => true, 'message' => 'Akun berhasil dibuat!', 'details' => $result['account_details']];
    } else {
        return ['success' => false, 'message' => 'Gagal membuat akun: ' . $result['error']];
    }
}

// Fungsi generate password acak
function generateRandomPassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $password;
}

// Fungsi generate detail akun (simulasi)
function generateAccountDetails($type, $username, $password, $server, $expiryDays) {
    $expiryDate = date('Y-m-d', strtotime("+$expiryDays days"));
    
    $details = "═══════════════════════════════════\n";
    $details .= "✅ AKUN VPN BERHASIL DIBUAT\n";
    $details .= "═══════════════════════════════════\n\n";
    
    $details .= "📋 Jenis Layanan: " . strtoupper($type) . "\n";
    $details .= "👤 Username: $username\n";
    
    if ($type === 'ssh') {
        $details .= "🔑 Password: $password\n";
    }
    
    $details .= "🌐 Server: " . $server['nama_server'] . "\n";
    $details .= "🔗 Domain: " . $server['domain'] . "\n";
    $details .= "📊 Quota: " . $server['quota'] . "GB\n";
    $details .= "📶 IP Limit: " . $server['iplimit'] . " IP\n";
    $details .= "⏰ Masa Aktif: $expiryDays hari\n";
    $details .= "📅 Expired: $expiryDate\n\n";
    
    // Tambahkan config berdasarkan jenis layanan
    switch ($type) {
        case 'ssh':
            $details .= "🔧 SSH Config:\n";
            $details .= "Host: " . $server['domain'] . "\n";
            $details .= "Port: 22\n";
            $details .= "Username: $username\n";
            $details .= "Password: $password\n";
            break;
            
        case 'vmess':
            $details .= "🔧 VMESS Config:\n";
            $details .= "Address: " . $server['domain'] . "\n";
            $details .= "Port: 443\n";
            $details .= "ID: " . generateUUID() . "\n";
            $details .= "Security: auto\n";
            $details .= "Network: ws\n";
            $details .= "Path: /vpn\n";
            break;
            
        case 'vless':
            $details .= "🔧 VLESS Config:\n";
            $details .= "Address: " . $server['domain'] . "\n";
            $details .= "Port: 443\n";
            $details .= "ID: " . generateUUID() . "\n";
            $details .= "Flow: xtls-rprx-direct\n";
            $details .= "Network: ws\n";
            break;
            
        case 'trojan':
            $details .= "🔧 Trojan Config:\n";
            $details .= "Address: " . $server['domain'] . "\n";
            $details .= "Port: 443\n";
            $details .= "Password: " . generateRandomPassword(16) . "\n";
            $details .= "Network: tcp\n";
            break;
            
        case 'shadowsocks':
            $details .= "🔧 Shadowsocks Config:\n";
            $details .= "Server: " . $server['domain'] . "\n";
            $details .= "Port: 8388\n";
            $details .= "Password: " . generateRandomPassword(16) . "\n";
            $details .= "Method: aes-256-gcm\n";
            break;
    }
    
    $details .= "\n═══════════════════════════════════\n";
    $details .= "⚠️ Jangan sebarkan config ini kepada siapapun!\n";
    $details .= "📞 Support: https://t.me/frel01\n";
    $details .= "═══════════════════════════════════";
    
    return $details;
}

// Fungsi generate UUID untuk VMESS/VLESS
function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
?>

<div class="animate-fade-in">
    <!-- Header -->
    <div class="card p-6 mb-6 bg-gradient-to-r from-purple-900 to-indigo-900">
        <div class="flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold">Buat Akun VPN</h2>
                <p class="text-purple-200">Buat akun VPN baru dengan konfigurasi lengkap</p>
            </div>
            <div class="mt-4 md:mt-0 flex items-center space-x-2 bg-purple-800 bg-opacity-50 px-4 py-2 rounded-lg">
                <i class="fas fa-wallet text-green-400"></i>
                <span class="font-semibold">Saldo: <?php echo formatCurrency(getUserBalance($_SESSION['user_id'])); ?></span>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
    <div class="card p-4 mb-6 <?php echo $messageType === 'success' ? 'bg-green-900' : 'bg-red-900'; ?>">
        <div class="flex items-center">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span><?php echo nl2br(htmlspecialchars($message)); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Info Auth Key (jika tersedia) -->
    <?php if (!empty($authKey)): ?>
    <div class="card p-4 mb-6 bg-blue-900">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="font-semibold text-blue-300">Auth Key Server:</h3>
                <p class="text-sm font-mono bg-gray-800 p-2 rounded mt-2"><?php echo htmlspecialchars($authKey); ?></p>
            </div>
            <button onclick="copyToClipboard('<?php echo htmlspecialchars($authKey); ?>')" class="bg-blue-700 hover:bg-blue-600 px-3 py-1 rounded">
                <i class="fas fa-copy"></i> Salin
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Detail Akun (jika berhasil dibuat) -->
    <?php if (!empty($accountDetails)): ?>
    <div class="card p-6 mb-6 bg-gray-800">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-bold text-green-400">
                <i class="fas fa-key mr-2"></i>Detail Akun
            </h3>
            <button onclick="copyToClipboard(`<?php echo htmlspecialchars($accountDetails); ?>`)" class="bg-green-700 hover:bg-green-600 px-3 py-2 rounded">
                <i class="fas fa-copy mr-1"></i> Salin Semua
            </button>
        </div>
        <pre class="bg-black p-4 rounded overflow-auto text-sm whitespace-pre-wrap"><?php echo htmlspecialchars($accountDetails); ?></pre>
    </div>
    <?php endif; ?>

    <!-- Form Buat Akun -->
    <div class="card p-6 mb-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-plus-circle mr-2 text-purple-400"></i> Form Buat Akun Baru
        </h2>
        
        <form method="POST" id="createForm">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-400 mb-2" for="username">Username</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500" 
                        placeholder="Masukkan username"
                        required
                        pattern="[a-zA-Z0-9]{3,20}"
                        title="Username harus 3-20 karakter (huruf dan angka saja)"
                    >
                    <p class="text-xs text-gray-500 mt-1">3-20 karakter (huruf dan angka)</p>
                </div>
                
                <div id="passwordField">
                    <label class="block text-gray-400 mb-2" for="password">Password (SSH Only)</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500" 
                        placeholder="Masukkan password untuk SSH"
                    >
                    <p class="text-xs text-gray-500 mt-1">Hanya untuk SSH, lainnya auto generate</p>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-400 mb-2" for="days">Masa Aktif (Hari)</label>
                    <input 
                        type="number" 
                        id="days" 
                        name="days" 
                        min="1" 
                        max="365" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500" 
                        placeholder="Jumlah hari"
                        required
                        value="30"
                    >
                </div>
                
                <div>
                    <label class="block text-gray-400 mb-2" for="type">Jenis Layanan</label>
                    <select 
                        id="type" 
                        name="type" 
                        class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                        onchange="togglePasswordField()"
                    >
                        <option value="ssh">SSH</option>
                        <option value="vmess">VMESS</option>
                        <option value="vless">VLESS</option>
                        <option value="trojan">Trojan</option>
                        <option value="shadowsocks">Shadowsocks</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-400 mb-2" for="server_id">Pilih Server</label>
                <select 
                    id="server_id" 
                    name="server_id" 
                    class="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
                    required
                    onchange="showAuthKey(this); calculatePrice()"
                >
                    <option value="">-- Pilih Server --</option>
                    <?php foreach ($servers as $server): 
                        $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                        $hargaPerHari = getDiscountedPrice($server['harga'], $_SESSION['role']);
                        $authKey = getServerAuth($server['id']);
                    ?>
                    <option value="<?php echo $server['id']; ?>" 
                            data-auth="<?php echo htmlspecialchars($authKey); ?>"
                            data-price="<?php echo $hargaPerHari; ?>"
                            <?php echo $isFull ? 'disabled' : ''; ?>>
                        <?php echo htmlspecialchars($server['nama_server']); ?> - 
                        <?php echo formatCurrency($hargaPerHari); ?>/hari
                        <?php echo $isFull ? ' (Penuh)' : ''; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Auth Key Display -->
            <div id="authKeySection" class="bg-gray-800 p-4 rounded mb-4 hidden">
                <h3 class="font-semibold mb-2 text-blue-300">Auth Key Server Terpilih:</h3>
                <div class="flex items-center justify-between">
                    <p id="authKeyDisplay" class="font-mono bg-gray-700 p-2 rounded flex-1 text-sm"></p>
                    <button type="button" onclick="copyAuthKey()" class="bg-blue-600 hover:bg-blue-500 px-3 py-2 rounded ml-2">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
            </div>
            
            <div class="bg-gray-800 p-4 rounded mb-4">
                <h3 class="font-semibold mb-2">Estimasi Biaya</h3>
                <div id="priceEstimation" class="text-lg font-semibold text-green-400">
                    Pilih server dan masa aktif untuk melihat estimasi biaya
                </div>
            </div>
            
            <button type="submit" class="btn-primary px-4 py-2 rounded font-semibold bg-purple-600 hover:bg-purple-700">
                <i class="fas fa-plus-circle mr-2"></i> Buat Akun
            </button>
        </form>
    </div>

    <!-- Daftar Server -->
    <div class="card p-6">
        <h2 class="text-xl font-bold mb-4 flex items-center">
            <i class="fas fa-server mr-2 text-purple-400"></i> Daftar Server Tersedia
        </h2>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-700">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Nama Server</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Auth Key</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Harga/Hari</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Quota</th>
                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php foreach ($servers as $server): 
                        $isFull = $server['total_create_akun'] >= $server['batas_create_akun'];
                        $hargaPerHari = getDiscountedPrice($server['harga'], $_SESSION['role']);
                        $authKey = getServerAuth($server['id']);
                    ?>
                    <tr>
                        <td class="px-4 py-3"><?php echo htmlspecialchars($server['nama_server']); ?></td>
                        <td class="px-4 py-3 font-mono text-xs" title="<?php echo htmlspecialchars($authKey); ?>">
                            <?php echo substr($authKey, 0, 15); ?>...
                        </td>
                        <td class="px-4 py-3"><?php echo formatCurrency($hargaPerHari); ?></td>
                        <td class="px-4 py-3"><?php echo $server['quota']; ?> GB</td>
                        <td class="px-4 py-3">
                            <?php if ($isFull): ?>
                                <span class="px-2 py-1 bg-red-600 text-xs rounded-full">Penuh</span>
                            <?php else: ?>
                                <span class="px-2 py-1 bg-green-600 text-xs rounded-full">Tersedia</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Toggle password field berdasarkan jenis layanan
    function togglePasswordField() {
        const type = document.getElementById('type').value;
        const passwordField = document.getElementById('passwordField');
        
        if (type === 'ssh') {
            passwordField.style.display = 'block';
            document.getElementById('password').setAttribute('required', 'required');
        } else {
            passwordField.style.display = 'none';
            document.getElementById('password').removeAttribute('required');
        }
    }
    
    // Tampilkan auth key saat server dipilih
    function showAuthKey(select) {
        const authKeySection = document.getElementById('authKeySection');
        const authKeyDisplay = document.getElementById('authKeyDisplay');
        
        if (select.value) {
            const selectedOption = select.options[select.selectedIndex];
            const authKey = selectedOption.getAttribute('data-auth');
            
            authKeyDisplay.textContent = authKey;
            authKeySection.classList.remove('hidden');
        } else {
            authKeySection.classList.add('hidden');
        }
    }
    
    // Hitung estimasi harga berdasarkan pilihan server da
